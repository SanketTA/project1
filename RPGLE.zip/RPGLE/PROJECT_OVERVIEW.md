# Employee Management RPGLE Project Overview

This document explains the complete working of the Employee Management project in `claudeoutput`.

## Project Requirement

The project manages employee data using two physical files:

- `EMPPF1`: Basic employee table used for the subfile list.
- `EMPPF2`: Detailed employee table used for add, display, edit, delete, and report.

The application should:

- Display all employee records from `EMPPF1` in a subfile.
- Add a new employee from a detail screen and write the record into both `EMPPF1` and `EMPPF2`.
- Display full employee details from `EMPPF2`.
- Edit employee details in `EMPPF2`.
- Delete employee records from both `EMPPF1` and `EMPPF2`.
- Print employee details using a printer file.
- Print a report filtered by department.
- Use procedures so all business/file logic is not kept inside one large RPGLE source.

## Source Files

### `EMPPF1.pf`

Physical file for Table-1. This stores basic employee details used by the subfile list.

Fields:

- `EMPID`: Employee ID, key field.
- `EMPNAME`: Employee name.
- `DEPT`: Department.

Key:

- `EMPID`

Important point:

- This file has `UNIQUE`, so duplicate `EMPID` values are not allowed.

### `EMPPF2.pf`

Physical file for Table-2. This stores full employee details.

Fields:

- `EMPID`: Employee ID, key field.
- `EMPNAME`: Employee name.
- `DEPT`: Department.
- `LOCATION`: Employee location.
- `DESIG`: Designation.
- `MOBNO`: Mobile number.
- `TECH`: Technology.

Key:

- `EMPID`

Important point:

- This file also has `UNIQUE`, so duplicate `EMPID` values are not allowed.

### `EMPDSPF.dspf`

Display file for all screens used by the interactive program.

Record formats:

- `SFLEMP`: Subfile record format. One employee row is written here.
- `SFLCTLEMP`: Subfile control format. Shows title, date, time, search field, headings, and controls subfile display.
- `SFLFOOT`: Footer showing function keys.
- `NODATA`: Message shown when no subfile records exist.
- `SCRADD`: Add employee detail screen.
- `SCRDSP`: Display employee detail screen.
- `SCRDLT`: Delete confirmation screen.
- `SCREDIT`: Edit employee detail screen.
- `SCRRPT`: Report filter screen.

Function keys:

- `F3`: Exit.
- `F6`: Add employee.
- `F7`: Print report.
- `F8`: Print one employee from display screen.
- `F12`: Cancel.
- `F16`: Confirm delete.

Important indicators:

- `25`: `SFLDSP`, displays subfile records.
- `26`: `SFLDSPCTL`, displays subfile control.
- `27`: `SFLCLR`, clears subfile.
- `28`: `SFLEND`, controls end/more display.
- `30`: `SFLNXTCHG`, used with changed subfile rows.
- `91`: Duplicate employee ID message on add screen.

### `EMPPRTF.prtf`

Printer file used for spool reports.

Record formats:

- `PRTHDR`: Report header.
- `PRTDET`: Employee detail line.
- `PRTTRL`: Trailer with total record count.

Important fields:

- `PHDATE`: Report date.
- `PHTIME`: Report time.
- `PHPAGNO`: Page number.
- `PHDEPT`: Department filter shown on report.
- `PTEMPID`: Printed employee ID.
- `PTENAME`: Printed employee name.
- `PTDEPT`: Printed department.
- `PTLOC`: Printed location.
- `PTDESIG`: Printed designation.
- `PTMOB`: Printed mobile number.
- `PTTECH`: Printed technology.
- `PTTOTAL`: Total records printed.

### `EMPPROTO.rpgleinc`

Copy member containing procedure prototypes.

This file is included using:

```rpgle
 /Copy DPSANKETA/KTTEST,EMPPROTO
```

Procedures declared here:

- `EMPADD`
- `EMPGET`
- `EMPDEL`
- `EMPUPD`
- `EMPPRTALL`
- `EMPPRTONE`

The main program uses this copy member so it knows the parameter list and return type of each procedure.

### `EMPPROC.rpgle`

Procedure module containing reusable employee file logic.

This file has `H NOMAIN`, so it does not run by itself. It is compiled as a module and bound with the main program.

Procedures:

#### `EMPADD`

Purpose:

- Add a new employee into both `EMPPF1` and `EMPPF2`.

Parameters:

- `P_EMPID`
- `P_ENAME`
- `P_DEPT`
- `P_LOC`
- `P_DESIG`
- `P_MOB`
- `P_TECH`

Return value:

- `*ON`: Employee ID already exists in `EMPPF1` or `EMPPF2`.
- `*OFF`: Employee was added successfully.

Working:

1. `CHAIN` `P_EMPID` to `EMPPF1`.
2. If found, return `*ON`.
3. `CHAIN` `P_EMPID` to `EMPPF2`.
4. If found, return `*ON`.
5. Write basic fields into `EMPPF1`.
6. Write full fields into `EMPPF2`.
7. Return `*OFF`.

#### `EMPGET`

Purpose:

- Fetch full employee details from `EMPPF2`.

Parameters:

- Input: `P_EMPID`
- Output: `P_OUTID`, `P_ENAME`, `P_DEPT`, `P_LOC`, `P_DESIG`, `P_MOB`, `P_TECH`

Return value:

- `*ON`: Employee found.
- `*OFF`: Employee not found.

Working:

1. `CHAIN` `P_EMPID` to `EMPPF2`.
2. If not found, return `*OFF`.
3. Move `EMPPF2` fields into output parameters.
4. Return `*ON`.

#### `EMPDEL`

Purpose:

- Delete employee from both `EMPPF1` and `EMPPF2`.

Parameter:

- `P_EMPID`

Return value:

- No return value.

Working:

1. `CHAIN` `P_EMPID` to `EMPPF1`.
2. If found, delete `REMP1`.
3. `CHAIN` `P_EMPID` to `EMPPF2`.
4. If found, delete `REMP2`.

#### `EMPUPD`

Purpose:

- Update employee details in `EMPPF2`.

Parameters:

- `P_EMPID`
- `P_ENAME`
- `P_DEPT`
- `P_LOC`
- `P_DESIG`
- `P_MOB`
- `P_TECH`

Return value:

- `*ON`: Record updated.
- `*OFF`: Employee ID not found in `EMPPF2`.

Working:

1. `CHAIN` `P_EMPID` to `EMPPF2`.
2. If not found, return `*OFF`.
3. Move edited values into `EMPPF2` fields.
4. Update `REMP2`.
5. Return `*ON`.

#### `EMPPRTALL`

Purpose:

- Print all employee records or only records for one department.

Parameters:

- `P_DEPT`: Department filter. Blank means all departments.
- `P_DATE`: Report date.
- `P_TIME`: Report time.

Return value:

- No return value.

Working:

1. Sets report header fields.
2. Writes `PRTHDR`.
3. Reads all records from `EMPPF2`.
4. If department filter is blank, prints every record.
5. If department filter has a value, prints matching `DEPT` records only.
6. Handles page overflow and increments page number.
7. Writes `PRTTRL` with total printed count.

#### `EMPPRTONE`

Purpose:

- Print one employee detail row from the display-detail screen.

Parameters:

- `P_EMPID`
- `P_ENAME`
- `P_DEPT`
- `P_LOC`
- `P_DESIG`
- `P_MOB`
- `P_TECH`
- `P_DATE`
- `P_TIME`

Return value:

- No return value.

Working:

1. Sets report header fields.
2. Writes `PRTHDR`.
3. Moves parameter values into printer detail fields.
4. Writes `PRTDET`.
5. Writes `PRTTRL` with total count `1`.

### `EMPRPGLE.rpgle`

Main RPGLE program. This controls the display screens, subfile, function keys, report flow, and calls procedures from `EMPPROC`.

Files declared:

- `EMPPF1`: Used to load the subfile.
- `EMPDSPF`: Workstation display file.

Important point:

- `EMPRPGLE` no longer declares `EMPPF2` or `EMPPRTF`.
- `EMPPROC` owns detailed employee file operations and report printing.

Main work variables:

- `WRK_RRN`: Subfile relative record number.
- `WRK_OPT`: Option entered in subfile row.
- `WRK_EMPID`: Selected employee ID.
- `WRK_DATE`: Current date.
- `WRK_TIME`: Current time.
- `WRK_LASTSRCH`: Last search value.
- `WRK_SRCHCHG`: Search changed flag.

Main subroutines:

#### `Sub_ClrSfl`

Clears the subfile.

Working:

1. Turns off `SFLDSP` and `SFLDSPCTL`.
2. Turns on `SFLCLR`.
3. Writes `SFLCTLEMP`.
4. Turns off `SFLCLR`.
5. Resets `WRK_RRN` to zero.

#### `Sub_RstKeys`

Resets function-key indicators.

Indicators reset:

- `D_Add`
- `D_RptKey`
- `D_PrtSpool`
- `D_Cancel`
- `D_Delete`

#### `Sub_LodSfl`

Loads records from `EMPPF1` into the subfile.

Working:

1. Positions to the start of `EMPPF1`.
2. Reads each record.
3. Applies search filter if `SRCHOPT` has a value.
4. Writes matching rows into `SFLEMP`.

Search checks:

- `EMPID`
- `EMPNAME`
- `DEPT`

#### `Sub_DspSfl`

Displays the subfile.

Working:

1. Moves date and time to display fields.
2. If records exist, turns on subfile display indicators.
3. If no records exist, shows `NODATA`.
4. Writes footer.

#### `Sub_AddEmp`

Handles F6 Add screen.

Working:

1. Clears add-screen fields.
2. Shows `SCRADD`.
3. If F12 is pressed, returns without saving.
4. Calls `EMPADD`.
5. If `EMPADD` returns `*ON`, duplicate message is shown and user can try again.
6. If `EMPADD` returns `*OFF`, record is saved and program returns to subfile.

#### `Sub_DspDtl`

Handles option `5`.

Working:

1. Calls `EMPGET` using selected employee ID.
2. If found, shows `SCRDSP`.
3. If F8 is pressed, calls `EMPPRTONE`.

#### `Sub_DelEmp`

Handles option `4`.

Working:

1. Calls `EMPGET` to load details.
2. Shows `SCRDLT`.
3. If F12 is pressed, returns without deleting.
4. If F16 is pressed, calls `EMPDEL`.
5. Main loop reloads the subfile after delete.

#### `Sub_EditEmp`

Handles option `2`.

Working:

1. Calls `EMPGET` to load existing details.
2. Shows `SCREDIT`.
3. If F12 is pressed, returns without saving.
4. If Enter is pressed, calls `EMPUPD`.

Important point:

- Edit updates `EMPPF2` only, matching the requirement. Because the subfile reads from `EMPPF1`, changed name/dept values may not show in the subfile unless `EMPPF1` is also updated later.

#### `Sub_RptFlt`

Handles F7 report option.

Working:

1. Clears `RPTDEPT`.
2. Shows `SCRRPT`.
3. If F12 is pressed, returns without printing.
4. If Enter is pressed, calls `EMPPRTALL`.

## Program Flow

### Initial Load

1. Program sets current date and time.
2. Clears the subfile.
3. Loads employee records from `EMPPF1`.
4. Displays the subfile.

### Main Subfile Screen

Available actions:

- `F3`: Exit program.
- `F6`: Add employee.
- `F7`: Print department report.
- Search field: Filter subfile records.
- Option `2`: Edit employee.
- Option `4`: Delete employee.
- Option `5`: Display employee details.

### Add Flow

1. User presses `F6`.
2. Program shows add screen.
3. User enters all employee fields.
4. Program calls `EMPADD`.
5. `EMPADD` writes to both physical files.
6. Subfile is cleared and reloaded.

### Display Flow

1. User enters option `5`.
2. Program calls `EMPGET`.
3. Program shows protected detail screen.
4. User can press `F8` to print that employee.

### Edit Flow

1. User enters option `2`.
2. Program calls `EMPGET`.
3. Program shows editable detail screen.
4. User edits values and presses Enter.
5. Program calls `EMPUPD`.
6. `EMPUPD` updates `EMPPF2`.

### Delete Flow

1. User enters option `4`.
2. Program calls `EMPGET`.
3. Program shows delete confirmation screen.
4. User presses `F16`.
5. Program calls `EMPDEL`.
6. `EMPDEL` deletes from both `EMPPF1` and `EMPPF2`.
7. Subfile is cleared and reloaded.

### Report Flow

1. User presses `F7`.
2. Program shows department filter screen.
3. User enters department or leaves it blank.
4. `EMPPRTALL` reads `EMPPF2`.
5. `EMPPRTALL` writes matching records into `EMPPRTF`.

This report reading and printing happens inside `EMPPRTALL` in `EMPPROC`.

## Compile Order

Create physical files:

```text
CRTPF FILE(DPSANKETA/EMPPF1) SRCFILE(DPSANKETA/KTTEST) SRCMBR(EMPPF1)
CRTPF FILE(DPSANKETA/EMPPF2) SRCFILE(DPSANKETA/KTTEST) SRCMBR(EMPPF2)
```

Create display and printer files:

```text
CRTDSPF FILE(DPSANKETA/EMPDSPF) SRCFILE(DPSANKETA/KTTEST) SRCMBR(EMPDSPF)
CRTPRTF FILE(DPSANKETA/EMPPRTF) SRCFILE(DPSANKETA/KTTEST) SRCMBR(EMPPRTF)
```

Create RPG modules:

```text
CRTRPGMOD MODULE(DPSANKETA/EMPPROC) SRCFILE(DPSANKETA/KTTEST) SRCMBR(EMPPROC)
CRTRPGMOD MODULE(DPSANKETA/EMPRPGLE) SRCFILE(DPSANKETA/KTTEST) SRCMBR(EMPRPGLE)
```

Create program:

```text
CRTPGM PGM(DPSANKETA/EMPRPGLE) MODULE(DPSANKETA/EMPRPGLE DPSANKETA/EMPPROC)
```

## Important Notes

- `EMPPROTO` must be copied into source file `KTTEST` as a copy member.
- `EMPPROC` must be compiled before binding the final program.
- `EMPRPGLE` is the main program.
- `EMPPROC` is not a standalone program because it uses `H NOMAIN`.
- Add writes to both tables.
- Delete deletes from both tables.
- Edit currently updates only `EMPPF2`, as per your requirement.
- The subfile displays data from `EMPPF1`.
- Reports print data from `EMPPF2`.
- Report printing is now handled by procedures, not by subroutines in `EMPRPGLE`.
