     H NOMAIN
     H OPTION(*NODEBUGIO)
     F*
     F*  Employee file procedures used by EMPRPGLE.
     F*  Compile:
     F*    CRTRPGMOD MODULE(DPSANKETA/EMPPROC) SRCFILE(DPSANKETA/KTTEST)
     F*              SRCMBR(EMPPROC)
     F*
     FEMPPF1    UF   E           K DISK
     FEMPPF2    UF   E           K DISK
     FEMPPRTF   O    E             PRINTER
     F                                     OFLIND(*IN90)
      /Copy DPSANKETA/KTTEST,EMPPROTO
     D WRK_TOTPRNT    S              4S 0
     P*
     P*==========================================================================
     P* EMPADD - Add employee into both tables.
     P* Returns *ON when duplicate EMPID exists, otherwise *OFF after save.
     P*==========================================================================
     P EMPADD          B                   EXPORT
     D EMPADD          PI             1N
     D  P_EMPID                       5A   Const
     D  P_ENAME                      30A   Const
     D  P_DEPT                       10A   Const
     D  P_LOC                        20A   Const
     D  P_DESIG                      20A   Const
     D  P_MOB                        12A   Const
     D  P_TECH                       20A   Const
     C*
     C     P_EMPID       Chain     REMP1
     C                   If        %Found(EMPPF1)
     C                   Return    *On
     C                   EndIf
     C     P_EMPID       Chain     REMP2
     C                   If        %Found(EMPPF2)
     C                   Return    *On
     C                   EndIf
     C*
     C                   Eval      EMPID       = %Trim(P_EMPID)
     C                   Eval      EMPNAME     = %Trim(P_ENAME)
     C                   Eval      DEPT        = %Trim(P_DEPT)
     C                   Write     REMP1
     C*
     C                   Eval      EMPID       = %Trim(P_EMPID)
     C                   Eval      EMPNAME     = %Trim(P_ENAME)
     C                   Eval      DEPT        = %Trim(P_DEPT)
     C                   Eval      LOCATION    = %Trim(P_LOC)
     C                   Eval      DESIG       = %Trim(P_DESIG)
     C                   Eval      MOBNO       = %Trim(P_MOB)
     C                   Eval      TECH        = %Trim(P_TECH)
     C                   Write     REMP2
     C*
     C                   Return    *Off
     P EMPADD          E
     P*
     P*==========================================================================
     P* EMPGET - Read employee detail from table 2.
     P* Returns *ON when found, *OFF when missing.
     P*==========================================================================
     P EMPGET          B                   EXPORT
     D EMPGET          PI             1N
     D  P_EMPID                       5A   Const
     D  P_OUTID                       5A
     D  P_ENAME                      30A
     D  P_DEPT                       10A
     D  P_LOC                        20A
     D  P_DESIG                      20A
     D  P_MOB                        12A
     D  P_TECH                       20A
     C*
     C     P_EMPID       Chain     REMP2
     C                   If        Not %Found(EMPPF2)
     C                   Return    *Off
     C                   EndIf
     C*
     C                   Eval      P_OUTID     = EMPID
     C                   Eval      P_ENAME     = EMPNAME
     C                   Eval      P_DEPT      = DEPT
     C                   Eval      P_LOC       = LOCATION
     C                   Eval      P_DESIG     = DESIG
     C                   Eval      P_MOB       = MOBNO
     C                   Eval      P_TECH      = TECH
     C*
     C                   Return    *On
     P EMPGET          E
     P*
     P*==========================================================================
     P* EMPDEL - Delete employee from both tables.
     P*==========================================================================
     P EMPDEL          B                   EXPORT
     D EMPDEL          PI
     D  P_EMPID                       5A   Const
     C*
     C     P_EMPID       Chain     REMP1
     C                   If        %Found(EMPPF1)
     C                   Delete    REMP1
     C                   EndIf
     C*
     C     P_EMPID       Chain     REMP2
     C                   If        %Found(EMPPF2)
     C                   Delete    REMP2
     C                   EndIf
     C*
     C                   Return
     P EMPDEL          E
     P*
     P*==========================================================================
     P* EMPUPD - Update employee detail in table 2.
     P* Returns *ON when updated, *OFF when EMPID is missing.
     P*==========================================================================
     P EMPUPD          B                   EXPORT
     D EMPUPD          PI             1N
     D  P_EMPID                       5A   Const
     D  P_ENAME                      30A   Const
     D  P_DEPT                       10A   Const
     D  P_LOC                        20A   Const
     D  P_DESIG                      20A   Const
     D  P_MOB                        12A   Const
     D  P_TECH                       20A   Const
     C*
     C     P_EMPID       Chain     REMP2
     C                   If        Not %Found(EMPPF2)
     C                   Return    *Off
     C                   EndIf
     C*
     C                   Eval      EMPNAME     = %Trim(P_ENAME)
     C                   Eval      DEPT        = %Trim(P_DEPT)
     C                   Eval      LOCATION    = %Trim(P_LOC)
     C                   Eval      DESIG       = %Trim(P_DESIG)
     C                   Eval      MOBNO       = %Trim(P_MOB)
     C                   Eval      TECH        = %Trim(P_TECH)
     C                   Update    REMP2
     C*
     C                   Return    *On
     P EMPUPD          E
     P*
     P*==========================================================================
     P* EMPPRTALL - Print all employees, or only one department.
     P*==========================================================================
     P EMPPRTALL       B                   EXPORT
     D EMPPRTALL       PI
     D  P_DEPT                       10A   Const
     D  P_DATE                       10A   Const
     D  P_TIME                        8A   Const
     C*
     C                   Eval      WRK_TOTPRNT = 0
     C                   Eval      PHDATE      = P_DATE
     C                   Eval      PHTIME      = P_TIME
     C                   Eval      PHPAGNO     = 1
     C*
     C                   If        %Trim(P_DEPT) = *Blank
     C                   Eval      PHDEPT      = 'ALL'
     C                   Else
     C                   Eval      PHDEPT      = %Trim(P_DEPT)
     C                   EndIf
     C*
     C                   Write     PRTHDR
     C                   SetLL     *LOVAL        REMP2
     C                   Read      EMPPF2
     C                   Dow       Not %EOF(EMPPF2)
     C*
     C                   If        *IN90         = *On
     C                   Eval      PHPAGNO       = PHPAGNO + 1
     C                   Write     PRTHDR
     C                   Eval      *IN90         = *Off
     C                   EndIf
     C*
     C                   If        %Trim(P_DEPT) = *Blank
     C                             Or %Trim(DEPT) = %Trim(P_DEPT)
     C                   Eval      PTEMPID     = EMPID
     C                   Eval      PTENAME     = EMPNAME
     C                   Eval      PTDEPT      = DEPT
     C                   Eval      PTLOC       = LOCATION
     C                   Eval      PTDESIG     = DESIG
     C                   Eval      PTMOB       = MOBNO
     C                   Eval      PTTECH      = TECH
     C                   Write     PRTDET
     C                   Eval      WRK_TOTPRNT = WRK_TOTPRNT + 1
     C                   EndIf
     C*
     C                   Read      EMPPF2
     C                   EndDo
     C*
     C                   Eval      PTTOTAL     = WRK_TOTPRNT
     C                   Write     PRTTRL
     C                   Return
     P EMPPRTALL       E
     P*
     P*==========================================================================
     P* EMPPRTONE - Print one employee detail row.
     P*==========================================================================
     P EMPPRTONE       B                   EXPORT
     D EMPPRTONE       PI
     D  P_EMPID                       5A   Const
     D  P_ENAME                      30A   Const
     D  P_DEPT                       10A   Const
     D  P_LOC                        20A   Const
     D  P_DESIG                      20A   Const
     D  P_MOB                        12A   Const
     D  P_TECH                       20A   Const
     D  P_DATE                       10A   Const
     D  P_TIME                        8A   Const
     C*
     C                   Eval      PHDATE      = P_DATE
     C                   Eval      PHTIME      = P_TIME
     C                   Eval      PHPAGNO     = 1
     C                   Eval      PHDEPT      = P_DEPT
     C                   Write     PRTHDR
     C*
     C                   Eval      PTEMPID     = P_EMPID
     C                   Eval      PTENAME     = P_ENAME
     C                   Eval      PTDEPT      = P_DEPT
     C                   Eval      PTLOC       = P_LOC
     C                   Eval      PTDESIG     = P_DESIG
     C                   Eval      PTMOB       = P_MOB
     C                   Eval      PTTECH      = P_TECH
     C                   Write     PRTDET
     C*
     C                   Eval      PTTOTAL     = 1
     C                   Write     PRTTRL
     C                   Return
     P EMPPRTONE       E
