     H*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     H* SOURCE MEMBER : EMPRPGLE
     H* TYPE          : RPG ILE Program (RPGLE)
     H* DESCRIPTION   : Employee Management System - Main Program
     H*
     H*  FEATURES:
     H*   - Subfile listing all employees from EMPPF1 (Table-1)
     H*   - F6  = Add New Employee  -> writes to EMPPF1 + EMPPF2
     H*   - Opt 5 = Display detail  -> reads from EMPPF2 (protected)
     H*             F8 in display   -> prints single emp to spool
     H*   - Opt 4 = Delete employee -> deletes from EMPPF1 + EMPPF2 (F16)
     H*   - Opt 2 = Edit employee   -> updates EMPPF2 only
     H*   - F7  = Print Report      -> dept filter screen then spool
     H*
     H*  ILE STRUCTURE:
     H*   - Screen/report flow is kept in this main program
     H*   - File add/get/delete/update/print logic is in EMPPROC procedures
     H*   - EMPPROTO copy member contains procedure prototypes
     H*
     H* LIBRARY       : DPSANKETA
     H* SOURCE FILE   : KTTEST
     H*
     H* COMPILE STEPS:
     H*   1. CRTRPGMOD MODULE(DPSANKETA/EMPPROC) SRCFILE(DPSANKETA/KTTEST)
     H*                SRCMBR(EMPPROC)
     H*   2. CRTRPGMOD MODULE(DPSANKETA/EMPRPGLE) SRCFILE(DPSANKETA/KTTEST)
     H*                SRCMBR(EMPRPGLE)
     H*   3. CRTPGM    PGM(DPSANKETA/EMPRPGLE)
     H*                MODULE(DPSANKETA/EMPRPGLE DPSANKETA/EMPPROC)
     H*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     H OPTION(*NODEBUGIO)
     H DFTACTGRP(*NO) ACTGRP(*NEW)
     H*
     H* -------------------------------------------------------------------------
     H*  FILE DECLARATIONS (F-Specs)
     H* -------------------------------------------------------------------------
     H*
     F*-- EMPPF1: Physical File Table-1 (basic employee info)
     F*   UF = Update capable (allows READ, WRITE, UPDATE, DELETE)
     F*   K  = Keyed access (by EMPID)
     FEMPPF1    UF   E           K DISK
     F*
     F*-- EMPDSPF: Display File (workstation)
     F*   CF = Combined file (input + output)
     F*   E  = Program-described? No, externally described
     F*   SFILE = Subfile record format + RRN work variable
     F*   INDDS = Use indicator data structure (Ds_Ind)
     FEMPDSPF   CF   E             WORKSTN
     F                                     SFILE(SFLEMP : WRK_RRN)
     F                                     INFDS(DS_INFD)
     F                                     INDDS(DS_IND)
     F*
      /Copy DPSANKETA/KTTEST,EMPPROTO
     H*
     H* -------------------------------------------------------------------------
     H*  DATA STRUCTURE DECLARATIONS (D-Specs)
     H* -------------------------------------------------------------------------
     H*
     D*-- DS for Display File Information (INFDS)
     D*   Gives us the cursor row/col, active format name etc.
     D DS_INFD        DS
     D  D_FMTNM              261    270         * Active format name
     D*
     D*-- Indicator Data Structure (INDDS)
     D*   Maps *IN01..*IN99 to named fields for readability
     D*   Based on work pointer (Wrk_Ind) set to %ADDR(*IN)
     D DS_IND         DS                  Based(Wrk_Ind)
     D  D_Exit                        1N  OverLay(DS_IND : 03)   * F3=Exit
     D  D_Add                         1N  OverLay(DS_IND : 06)   * F6=Add
     D  D_RptKey                      1N  OverLay(DS_IND : 07)   * F7=Rpt
     D  D_PrtSpool                    1N  OverLay(DS_IND : 08)   * F8=Print
     D  D_Cancel                      1N  OverLay(DS_IND : 12)   * F12=Cancel
     D  D_Delete                      1N  OverLay(DS_IND : 16)   * F16=Delete
     D  D_SflDsp                      1N  OverLay(DS_IND : 25)   * SFLDSP
     D  D_SflDspCtl                   1N  OverLay(DS_IND : 26)   * SFLDSPCTL
     D  D_SflClr                      1N  OverLay(DS_IND : 27)   * SFLCLR
     D  D_SflEnd                      1N  OverLay(DS_IND : 28)   * SFLEND
     D  D_SflNxtChg                   1N  OverLay(DS_IND : 30)   * SFLNXTCHG
     D  D_EmpExists                   1N  OverLay(DS_IND : 91)   * Dup ID err
     D*
     D*-- Pointer for indicator DS (points to *IN array base address)
     D Wrk_Ind        S               *   Inz(%Addr(*In))
     D*
     D*-- Work Variables
     D WRK_RRN        S              4S 0                         * Subfile RRN
     D WRK_OPT        S              2A                           * Option chosen
     D WRK_EMPID      S              5A                           * Selected EMPID
     D WRK_LASTSRCH   S             10A                           * Last search value
     D WRK_SRCHCHG    S              1N                           * Search changed
     D*
     D*-- Constants
     D Con_On         C                   Const(*On)
     D Con_Off        C                   Const(*Off)
     D*
     D*-- Current Date / Time (formatted as strings for display)
     D WRK_DATE       S             10A
     D WRK_TIME       S              8A
     D*
     H* =========================================================================
     H*  MAIN LOGIC (C-Specs)
     H* =========================================================================
     H*
     C*-- Step 1: Capture current date and time for screen headers
     C                   EVAL      WRK_DATE = %char(%date():*ISO)
     C                   EVAL      WRK_TIME = %char(%time():*ISO)
     C*
     C*-- Step 2: Load subfile with all records from EMPPF1
     C                   ExSr      Sub_ClrSfl
     C                   ExSr      Sub_LodSfl
     C                   ExSr      Sub_DspSfl
     C*
     C*-- Step 3: Main event loop - keep showing subfile until F3=Exit
     C                   Dow       D_Exit    <> Con_On
     C*
     C*--   Show the subfile control and wait for user input
     C                   ExSr      Sub_RstKeys
     C                   ExFmt     SFLCTLEMP
     C*
     C*--   Check which function key was pressed
     C*
     C*   F3=Exit: handled by DOW condition above (D_Exit = *ON breaks loop)
     C*
     C*--   F6=Add New Employee
     C                   If        D_Add     =  Con_On
     C                   ExSr      Sub_AddEmp
     C                   ExSr      Sub_ClrSfl
     C                   ExSr      Sub_LodSfl
     C                   ExSr      Sub_DspSfl
     C                   EndIf
     C*
     C*--   F7=Print Report (dept filter then spool)
     C                   If        D_RptKey  =  Con_On
     C                   ExSr      Sub_RptFlt
     C                   ExSr      Sub_ClrSfl
     C                   ExSr      Sub_LodSfl
     C                   ExSr      Sub_DspSfl
     C                   EndIf
     C*
     C*--   Search: reload subfile only when search text changes
     C                   Eval      WRK_SRCHCHG = Con_Off
     C                   If        D_Add     <> Con_On
     C                   If        D_RptKey  <> Con_On
     C                   If        %Trim(SRCHOPT) <> %Trim(WRK_LASTSRCH)
     C                   Eval      WRK_SRCHCHG  = Con_On
     C                   Eval      WRK_LASTSRCH = SRCHOPT
     C                   ExSr      Sub_ClrSfl
     C                   ExSr      Sub_LodSfl
     C                   ExSr      Sub_DspSfl
     C                   EndIf
     C                   EndIf
     C                   EndIf
     C*
     C*--   Process Subfile Options (2=Edit, 4=Delete, 5=Display)
     C*    READC reads only changed subfile records (those with an OPT entered)
     C                   If        D_Add     <> Con_On
     C                   If        D_RptKey  <> Con_On
     C                   If        WRK_SRCHCHG = Con_Off
     C                   Eval      WRK_RRN   =  1
     C                   ReadC     SFLEMP
     C                   Dow       Not %EOF(EMPDSPF)
     C*
     C*       Capture the option and EMPID the user typed
     C                   Eval      WRK_OPT   =  %Trim(SFLOPT)
     C                   Eval      WRK_EMPID =  %Trim(SFEMPID)
     C*
     C*       Option 5 - Display Detail
     C                   If        WRK_OPT   = '5'
     C                   ExSr      Sub_DspDtl
     C                   EndIf
     C*
     C*       Option 4 - Delete Employee
     C                   If        WRK_OPT   = '4'
     C                   ExSr      Sub_DelEmp
     C                   ExSr      Sub_ClrSfl
     C                   ExSr      Sub_LodSfl
     C                   ExSr      Sub_DspSfl
     C                   Leave
     C                   EndIf
     C*
     C*       Option 2 - Edit Employee
     C                   If        WRK_OPT   = '2'
     C                   ExSr      Sub_EditEmp
     C                   EndIf
     C*
     C*       Read next changed subfile record
     C                   ReadC     SFLEMP
     C                   EndDo
     C                   EndIf
     C                   EndIf
     C                   EndIf
     C*
     C                   EndDo
     C                   ExSr      Sub_RstKeys
     C*-- End of Main Loop
     C*
     C*-- Step 4: Clean exit
     C                   Eval      *InLR     =  *On
     C                   Return
     H*
     H* =========================================================================
     H*  SUBROUTINE: Sub_ClrSfl
     H*  PURPOSE   : Clear (initialize) the subfile before re-loading
     H*              Turn off SFLDSP so writing to a cleared subfile doesn't error
     H* =========================================================================
     C     Sub_ClrSfl    BegSr
     C*
     C*-- Turn off display indicators before clearing
     C                   Eval      D_SflDsp    = Con_Off
     C                   Eval      D_SflDspCtl = Con_Off
     C                   Eval      D_SflClr    = Con_On
     C*
     C*-- Write SFLCTLEMP with SFLDSP off = clears subfile
     C                   Write     SFLCTLEMP
     C                   Eval      D_SflClr    = Con_Off
     C*
     C*-- Reset RRN counter
     C                   Eval      WRK_RRN     = 0
     C*
     C                   EndSr
     H*
     H* =========================================================================
     H*  SUBROUTINE: Sub_RstKeys
     H*  PURPOSE   : Reset function-key indicators before/after EXFMT
     H* =========================================================================
     C     Sub_RstKeys   BegSr
     C*
     C                   Eval      D_Add       = Con_Off
     C                   Eval      D_RptKey    = Con_Off
     C                   Eval      D_PrtSpool  = Con_Off
     C                   Eval      D_Cancel    = Con_Off
     C                   Eval      D_Delete    = Con_Off
     C*
     C                   EndSr
     H*
     H* =========================================================================
     H*  SUBROUTINE: Sub_LodSfl
     H*  PURPOSE   : Read all records from EMPPF1 and write to subfile
     H* =========================================================================
     C     Sub_LodSfl    BegSr
     C*
     C*-- Position to start of EMPPF1
     C                   SetLL     *LOVAL        REMP1
     C*
     C*-- Read first record
     C                   Read      EMPPF1
     C*
     C*-- Loop until end of file
     C                   Dow       Not %EOF(EMPPF1)
     C*
     C*--   Apply search against EMPID, EMPNAME, or DEPT
     C                   If        %Trim(SRCHOPT) = *Blank
     C                             Or %Scan(%Trim(SRCHOPT):EMPID) > 0
     C                             Or %Scan(%Trim(SRCHOPT):EMPNAME) > 0
     C                             Or %Scan(%Trim(SRCHOPT):DEPT) > 0
     C*
     C*--   Increment RRN (subfile record number)
     C                   Eval      WRK_RRN     = WRK_RRN + 1
     C*
     C*--   Move PF1 fields into subfile fields
     C                   Eval      SFEMPID     = EMPID
     C                   Eval      SFENAME     = EMPNAME
     C                   Eval      SFDEPT      = DEPT
     C*
     C*--   Clear OPT so no stale option appears
     C                   Eval      SFLOPT      = *Blank
     C*
     C*--   Write this row into the subfile
     C                   Write     SFLEMP
     C                   EndIf
     C*
     C*--   Read next record from EMPPF1
     C                   Read      EMPPF1
     C                   EndDo
     C*
     C                   EndSr
     H*
     H* =========================================================================
     H*  SUBROUTINE: Sub_DspSfl
     H*  PURPOSE   : Turn on indicators to display the subfile
     H*              If no records loaded, show NODATA message instead
     H* =========================================================================
     C     Sub_DspSfl    BegSr
     C*
     C*-- Copy date/time into control record fields
     C                   Eval      CURDATE     = WRK_DATE
     C                   Eval      CURTIME     = WRK_TIME
     C*
     C                   If        WRK_RRN    <> *Zero
     C*--   Records exist: turn on display indicators
     C                   Eval      D_SflDsp    = Con_On
     C                   Eval      D_SflDspCtl = Con_On
     C                   Eval      D_SflEnd    = Con_On
     C                   Eval      WRK_RRN     = 1
     C*--   Write footer (function key bar)
     C                   Write     SFLFOOT
     C                   Else
     C*--   No records: show "No Data Found" overlay
     C                   Eval      D_SflDsp    = Con_Off
     C                   Eval      D_SflDspCtl = Con_On
     C                   Write     NODATA
     C                   Write     SFLFOOT
     C                   EndIf
     C*
     C                   EndSr
     H*
     H* =========================================================================
     H*  SUBROUTINE: Sub_AddEmp
     H*  PURPOSE   : Show Add screen (SCRADD), validate, write to PF1 + PF2
     H* =========================================================================
     C     Sub_AddEmp    BegSr
     C*
     C*-- Clear all add-screen fields before showing
     C                   Eval      ADEMPID     = *Blank
     C                   Eval      ADENAME     = *Blank
     C                   Eval      ADDEPT      = *Blank
     C                   Eval      ADLOC       = *Blank
     C                   Eval      ADDESIG     = *Blank
     C                   Eval      ADMOB       = *Blank
     C                   Eval      ADTECH      = *Blank
     C                   Eval      D_EmpExists = Con_Off
     C*
     C*-- Show add screen until saved, or F12 cancels
     C                   Dow       D_Cancel    <> Con_On
     C                   ExSr      Sub_RstKeys
     C                   ExFmt     SCRADD
     C*
     C                   If        D_Cancel    =  Con_On
     C                   Leave
     C                   EndIf
     C*
     C*-- EMPADD returns *ON only when duplicate EMPID exists
     C                   Eval      D_EmpExists =
     C                             EMPADD(ADEMPID:ADENAME:ADDEPT:
     C                                    ADLOC:ADDESIG:ADMOB:ADTECH)
     C                   If        D_EmpExists =  Con_Off
     C                   Leave
     C                   EndIf
     C                   EndDo
     C*
     C                   EndSr
     H*
     H* =========================================================================
     H*  SUBROUTINE: Sub_DspDtl
     H*  PURPOSE   : Option 5 - Display full employee detail from EMPPF2
     H*              F8 in this screen prints a single employee to spool
     H* =========================================================================
     C     Sub_DspDtl    BegSr
     C*
     C*-- Fetch details from EMPPF2 using procedure
     C                   If        EMPGET(WRK_EMPID:DSEMPID:DSENAME:
     C                                    DSDEPT:DSLOC:DSDESIG:
     C                                    DSMOB:DSTECH) = Con_Off
     C                   Return
     C                   EndIf
     C*
     C*-- Show display screen (all fields protected/output only)
     C                   ExSr      Sub_RstKeys
     C                   ExFmt     SCRDSP
     C*
     C*-- Check if F8=Print was pressed (print this single employee)
     C                   If        D_PrtSpool  =  Con_On
     C                   CallP     EMPPRTONE(DSEMPID:DSENAME:DSDEPT:
     C                                    DSLOC:DSDESIG:DSMOB:DSTECH:
     C                                    WRK_DATE:WRK_TIME)
     C                   EndIf
     C*
     C*-- F12=Cancel or ENTER just returns to subfile
     C                   EndSr
     H*
     H* =========================================================================
     H*  SUBROUTINE: Sub_DelEmp
     H*  PURPOSE   : Option 4 - Show Delete screen, confirm with F16
     H*              Deletes from EMPPF1 and EMPPF2
     H* =========================================================================
     C     Sub_DelEmp    BegSr
     C*
     C*-- Fetch details from EMPPF2 for protected delete screen
     C                   If        EMPGET(WRK_EMPID:DLEMPID:DLENAME:
     C                                    DLDEPT:DLLOC:DLDESIG:
     C                                    DLMOB:DLTECH) = Con_Off
     C                   Return
     C                   EndIf
     C*
     C*-- Show delete screen (protected fields, F16 to confirm)
     C                   ExSr      Sub_RstKeys
     C                   ExFmt     SCRDLT
     C*
     C*-- Check if F12=Cancel was pressed
     C                   If        D_Cancel    =  Con_On
     C                   Return
     C                   EndIf
     C*
     C*-- Only delete if F16 was pressed
     C                   If        D_Delete    =  Con_On
     C                   CallP     EMPDEL(WRK_EMPID)
     C*
     C                   EndIf
     C*
     C                   EndSr
     H*
     H* =========================================================================
     H*  SUBROUTINE: Sub_EditEmp
     H*  PURPOSE   : Option 2 - Show Edit screen, save changes to EMPPF2
     H*              EMPID is protected; all other fields are editable
     H* =========================================================================
     C     Sub_EditEmp   BegSr
     C*
     C*-- Fetch current values from EMPPF2
     C                   If        EMPGET(WRK_EMPID:EDEMPID:EDENAME:
     C                                    EDDEPT:EDLOC:EDDESIG:
     C                                    EDMOB:EDTECH) = Con_Off
     C                   Return
     C                   EndIf
     C*
     C*-- Show edit screen and wait for ENTER or F12
     C                   ExSr      Sub_RstKeys
     C                   ExFmt     SCREDIT
     C*
     C*-- F12=Cancel - don't save
     C                   If        D_Cancel    =  Con_On
     C                   Return
     C                   EndIf
     C*
     C*-- ENTER pressed: save updated values back to EMPPF2
     C                   CallP     EMPUPD(EDEMPID:EDENAME:EDDEPT:
     C                                    EDLOC:EDDESIG:EDMOB:EDTECH)
     C*
     C                   EndSr
     H*
     H* =========================================================================
     H*  SUBROUTINE: Sub_RptFlt
     H*  PURPOSE   : F7 - Show report filter screen (enter Dept or blank=ALL)
     H*              Then call EMPPRTALL to generate spool report
     H* =========================================================================
     C     Sub_RptFlt    BegSr
     C*
     C*-- Clear Dept filter field
     C                   Eval      RPTDEPT     = *Blank
     C*
     C*-- Show report filter screen
     C                   ExSr      Sub_RstKeys
     C                   ExFmt     SCRRPT
     C*
     C*-- F12=Cancel - return without printing
     C                   If        D_Cancel    =  Con_On
     C                   Return
     C                   EndIf
     C*
     C*-- ENTER pressed - generate report
     C                   CallP     EMPPRTALL(RPTDEPT:WRK_DATE:WRK_TIME)
     C*
     C                   EndSr
     H*
